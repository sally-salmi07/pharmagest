package PharmaGest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class databaseConnection {
    public Connection databaseLink;

    public Connection getConnection() throws SQLException {
        String url = "jdbc:postgres://localhost:5432/pharmacie";
        String databasename = "pharmacie";
        String databaseuser = "postgres";
        String databasePassword ="Salimiyati06";

        Connection conn = null;

        try{
            conn = DriverManager.getConnection(url, databaseuser, databasePassword);

        }
        catch (Exception e){
            e.printStackTrace();
            e.getCause();
        }
        return conn;
    }
}
